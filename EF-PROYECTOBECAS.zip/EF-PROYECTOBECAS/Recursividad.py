import sys, time
sys.setrecursionlimit(10000)
#Permite que el programa se llame a si mismo hasta 10000 vueltas


NIVEL_STR = {1: "Bajo", 2: "Medio", 3: "Alto"}
CATEGORIAS = [("excelencia", 18.00, "≥ 18.00"), ("honor", 16.00, "16.00 - 17.99"),
              ("estimulo", 14.00, "14.00 - 15.99")]


class Estudiante:
    def __init__(self, id, nombre, promedio, nse, creditos, fecha):
        self.id, self.nombre, self.promedio = id, nombre, promedio
        self.nivel_socioeconomico, self.creditos_aprobados, self.fecha_solicitud = nse, creditos, fecha

    def __repr__(self):
        return f"{self.nombre} (Promedio: {self.promedio}, NSE: {self.nivel_socioeconomico})"


def titulo(texto, ancho=60, c="="):
    print("\n" + c * ancho + f"\n{texto}\n" + c * ancho)


# ========== VALIDACIÓN GENÉRICA ==========
def pedir_valor(mensaje, tipo, condicion=lambda v: True, error="Valor inválido."):
    while True:
        valor = input(mensaje).strip()
        try:
            valor = tipo(valor)
            if condicion(valor):
                return valor
            print(f" ERROR: {error}")
        except ValueError:
            print(f" ERROR: {error}")


def validar_nombre(nombre):
    return bool(nombre.strip()) and all(c.isalpha() or c.isspace() for c in nombre)


# ========== ENTRADA DE DATOS ==========
def ingresar_estudiante_manual(id_est, fecha_base):
    titulo(f"INGRESO DE ESTUDIANTE #{id_est}", 50)  #Encabezado visual
    if id_est > 1 and input("\n¿Desea ingresar otro estudiante? (s/n): ").lower().strip() not in ("s", "si"):
        return None #Se genera la pregunta a partir del segundo estudiantes

    while True: #Captura y a travez de los validadores, muestra si esta correcto(avanza) o si no muestra error
        nombre = input("\nIngrese el nombre completo del estudiante: ").strip()
        if validar_nombre(nombre):
            break
        print(" ERROR: El nombre no puede estar vacío y solo debe contener letras y espacios.")
    #Captura el promedio a travez de pedir valor
    promedio = pedir_valor("Ingrese el promedio final (0.00 - 20.00): ", float,
                            lambda v: 0 <= v <= 20, "El promedio debe estar entre 0.00 y 20.00")
    #Mostramos el menu de opciones, y a travez de las validaciones hacemos que ponga 1,2 o 3. OJO el ns se guarda cm entero
    print("\nNivel Socioeconómico:\n  1 = Bajo\n  2 = Medio\n  3 = Alto")
    nse = pedir_valor("Seleccione el nivel socioeconómico (1-3): ", int,
                       lambda v: v in (1, 2, 3), "Debe ser 1 (bajo), 2 (medio) o 3 (alto)")
    
    ##Validacio de creditos, que sea >= 0 
    creditos = pedir_valor("Ingrese el número de créditos aprobados: ", int,
                            lambda v: v >= 0, "Debe ser un entero no negativo")

    #Tomamos las variables validas y creamos el objeto. Al final muestra el mensaje de exito y devuelve el objeto listo para guardarlo en lista
    est = Estudiante(id_est, nombre, promedio, nse, creditos, fecha_base + id_est)
    print(f"\n Estudiante '{nombre}' registrado exitosamente.")
    return est

#Define cuantas becas hay disponibles para cada categoria, se lee de forma inversa
#1- Vuelta 1: El final: Arranca todo, lee lo de categorias. El(_), es un truco para no obtener
#el segundo dato que es (nota), ya que python lo ignora
#2- Accion: ejecuta pedir valor que es la validacion
#3- y crea al final un diccionario.
def ingresar_cupos():
    titulo("CONFIGURACIÓN DE CUPOS POR CATEGORÍA", 50)
    return {
        cat: pedir_valor(f"\nCupos para Beca {cat.capitalize()} ({rango}): ", int,
                          lambda v: v >= 0, "El número de cupos no puede ser negativo")
        for cat, _, rango in CATEGORIAS
        #Agarro la categoria y rango de CATEGORIAS
    }

#Clasifica automaticamente en que categoria de beca entra un alumno segun nota de su promedio
def determinar_categoria(promedio):
    for cat, umbral, _ in CATEGORIAS:
        #Compara prom. alumno con umbral minimo
        if promedio >= umbral:
            return cat
            #En caso es >=, al final muesrtra el nombre de la categoria ganada
    return None
    #En caso no pase ningun umbral minimo, llega aca y devuelve none= "Sin beca"


# ========== RECURSIVIDAD y BACKTRACKING ==========
#Reajusta en caso la categoria este llena
def backtracking_reasignacion(estudiante, categoria_original, asignacion, cupos):
    """Si la categoría está llena, intenta ubicarlo en categorías inferiores."""
    nombres = [c for c, _, _ in CATEGORIAS]
    
    #En caso la categoria no exista
    if categoria_original not in nombres:
        return False
    
    #1. Busca la posicion de la beca del alumno
    #2. Suma 1 a la posicion que esta(en codigo, lo baja de rango)
    for cat_inf in nombres[nombres.index(categoria_original) + 1:]:
        
        #Pregunta si es que puede ingresar, si si, lo reasigna
        if len(asignacion[cat_inf]) < cupos[cat_inf]:
            asignacion[cat_inf].append(estudiante)
            return True
    return False
    #En caso no pueda ingresar devuelve false

#Toma la lista de todos los alumnos y los reparte a sus becas
def asignar_becas_recursivo(estudiantes, cupos, indice=0, asignacion=None):
    """Estrategia principal: Recursividad"""
    #Creo un diccionario (asignacion), creandose para poder completar con los alumnos
    if asignacion is None:
        asignacion = {"excelencia": [], "honor": [], "estimulo": [], "sin_beca": []}

    #Si el indice= tamaño es decir ya paso por toda la lista, y al final devuelvo el la asignacion 
    if indice >= len(estudiantes):
        return asignacion

    #Saca de la lista al estudiante
    est = estudiantes[indice]

    #En caso su promedio es menor a 14 directo a sin beca
    if est.promedio < 14.00:
        asignacion["sin_beca"].append(est)

    #Si tiene mas se llama a determinar categoria y averigua la veca
    else:
        categoria = determinar_categoria(est.promedio)

        #Si existe la categoria y todavia quedan asientos libres, el estudiante gana su beca ideal
        if categoria and len(asignacion[categoria]) < cupos[categoria]:
            asignacion[categoria].append(est)
        
        #En caso tenga beca y este llena se llama a la reasignacion, y si no queda se llama a sin beca
        elif not backtracking_reasignacion(est, categoria, asignacion, cupos):
            asignacion["sin_beca"].append(est)

    return asignar_becas_recursivo(estudiantes, cupos, indice + 1, asignacion)
#Al final se llama a si misma pero para evaluar al otro alumno, compartiendole el diccionario de asignacion, para llenarse con nuevos datos

# ========== ORDENAMIENTO BURBUJA  ==========
#Compara estudiantes para elegir cual tiene mas derecho, si los cupos son limitados
def debe_intercambiar(e1, e2):
    """Criterios: mayor promedio > menor NSE > más créditos > solicitud más antigua."""
    #Notas diferentes= Ordena de mayor a menor
    if e1.promedio != e2.promedio:
        return e1.promedio < e2.promedio
    
    #En caso los promedios sean iguales, le da prioricad al que tenga menor nivel socioeconomico
    if e1.nivel_socioeconomico != e2.nivel_socioeconomico:
        return e1.nivel_socioeconomico > e2.nivel_socioeconomico

    #En calo los dos primers criterios sean iguales, este le da al que tenga mas creditos    
    if e1.creditos_aprobados != e2.creditos_aprobados:
        return e1.creditos_aprobados < e2.creditos_aprobados
    return e1.fecha_solicitud > e2.fecha_solicitud
#Si todos los anteriores osn iguales, gana la que se digito primero


#Toma la lista y los reacomoda completamente
def ordenar_estudiantes_recursivo(estudiantes, n=None):
    """Ordenamiento Burbuja Recursivo. Complejidad: O(n²)."""

    #La primera vuelta no llamo a n. Asi que lo detecta y mide el tamaño de lista
    n = len(estudiantes) if n is None else n

    #Si el tamaño es de 1 o menos, la funcion para y devuelve la lista
    if n <= 1:
        return estudiantes
    
    #Recorre la listaa comparando estudiantes. llama a debe intercambiar
    # y si tiene mas derecho de de la derch que el de la izq
    #  se intercambian de lugar. ordenandolos, el de menor al ultimo
    for i in range(n - 1):
        if debe_intercambiar(estudiantes[i], estudiantes[i + 1]):
            estudiantes[i], estudiantes[i + 1] = estudiantes[i + 1], estudiantes[i]
   
    #Como se esta ordenando del utlomo, ya no hay necesidad de ponerlo. Por eso se le pasa a n-1
    #Le dice a python, haz lo mismo pero ignora la casilla porque ya esta en su lugar correcto.
    return ordenar_estudiantes_recursivo(estudiantes, n - 1)


# ========== RESULTADOS ==========
#Muestra los resultados obtenidos.
def mostrar_resultados(asignacion, cupos, total):
    titulo(" RESULTADOS DE ASIGNACIÓN DE BECAS\n   Estrategia: Recursividad con Backtracking")
   
    #Usa el bucle para que cuente los alumnos que hay en las listas, excelecia, honor y estimulo
    con_beca = sum(len(asignacion[c]) for c in ("excelencia", "honor", "estimulo"))
    print(f"\n Total de estudiantes procesados: {total}")
    print(f" Total de estudiantes con beca asignada: {con_beca}")
    print(f" Total de estudiantes sin beca: {len(asignacion['sin_beca'])}")

    #Se crea un diccionario, con emojis para una mejor estetica visual y corre el bucle categorias
    emojis = {"excelencia": "🌟 BECA EXCELENCIA", "honor": "🎓 BECA HONOR", "estimulo": "📚 BECA ESTÍMULO"}
    for cat, _, rango in CATEGORIAS:
        print(f"\n{emojis[cat]} ({rango})")

        #Por cada categoria, muestra los cupos totales vs cuantos se llenaros realmente
        print(f"Cupos disponibles: {cupos[cat]} | Asignados: {len(asignacion[cat])}")
        print("-" * 50)
        if not asignacion[cat]:
            print("  Sin asignaciones en esta categoría")

        #Usa el enumerate para numerar y se usa el nivel_str para ver su nivel socioeconomico
        for i, e in enumerate(asignacion[cat], 1):
            print(f"  {i}. {e.nombre}\n     Promedio: {e.promedio:.2f} | "
                  f"NSE: {NIVEL_STR[e.nivel_socioeconomico]} | Créditos: {e.creditos_aprobados}")

    #Si no tienen beca los pone en: 1. Jalados o con promedio menor al requisito minimo <14
    #y a los que a pesar de tener un promedio mayor a 14, merecian la beca pero se quedaron fuera porque se llenaron
    if asignacion["sin_beca"]:
        print(f"\n❌ ESTUDIANTES SIN BECA ({len(asignacion['sin_beca'])}):\n" + "-" * 50)
        no_alcanzan = [e for e in asignacion["sin_beca"] if e.promedio < 14.00]
        sin_cupo = [e for e in asignacion["sin_beca"] if e.promedio >= 14.00]

        if no_alcanzan:
            print(f"\n  No alcanzan nota mínima (< 14.00): {len(no_alcanzan)}")
            for e in no_alcanzan[:5]:
                print(f"    - {e.nombre} (Promedio: {e.promedio:.2f})")
            if len(no_alcanzan) > 5:
                print(f"    ... y {len(no_alcanzan) - 5} más")

        if sin_cupo:
            print(f"\n  Sin cupo disponible en su categoría: {len(sin_cupo)}")
            nombres_cat = {"excelencia": "Excelencia", "honor": "Honor", "estimulo": "Estímulo"}
            for e in sin_cupo[:5]:
                cat = determinar_categoria(e.promedio)
                print(f"    - {e.nombre} (Promedio: {e.promedio:.2f} → {nombres_cat.get(cat, 'N/A')})")
            if len(sin_cupo) > 5:
                print(f"    ... y {len(sin_cupo) - 5} más")
# el For [:5] solo muestra los primeros 5 primeros nombres de cada grupo 
# y abajo ponemos cuantos mas hay pero estan ocualotos


#Muestra una tabla limpia y ordenada con todos los alumnos registrados
def mostrar_resumen_estudiantes(estudiantes):
    titulo("📋 LISTA DE ESTUDIANTES INGRESADOS")
    print(f"\nTotal de estudiantes: {len(estudiantes)}\n")

    #Alineamos a la izquiera los datos con un espacio fijo, a travez de los numeros:
    print(f"{'ID':<5} {'Nombre':<25} {'Promedio':<10} {'NSE':<8} {'Créditos':<10}")
    print("-" * 58)

    #Recorre los estudiantes, reutiliza los aliamientos. y muestra
    for e in estudiantes:
        print(f"{e.id:<5} {e.nombre:<25} {e.promedio:<10.2f} {NIVEL_STR[e.nivel_socioeconomico]:<8} {e.creditos_aprobados:<10}")


# ========== PROGRAMA PRINCIPAL ==========

#Y al fonal con el main, conectamos, en buen orden cada funcion individual que hemos realizado
#Para que funcione el sofware completo
def main():
    titulo("🎓 SISTEMA DE ASIGNACIÓN DE BECAS UNIVERSITARIAS\n   Estrategia: Recursividad")
    print("\n📌 INSTRUCCIONES:")
    print("   - El promedio debe estar entre 0.00 y 20.00.")
    print("   - Solo se consideran para beca promedios ≥ 14.00.")

    cupos = ingresar_cupos()

    titulo("INGRESO DE ESTUDIANTES POSTULANTES")
    estudiantes, id_est, fecha_base = [], 1, 1000
    while True:
        est = ingresar_estudiante_manual(id_est, fecha_base)
        if est is None:
            if id_est == 1:
                print("\n❌ Debe ingresar al menos un estudiante.")
                continue
            break
        estudiantes.append(est)
        id_est += 1

    mostrar_resumen_estudiantes(estudiantes)

    inicio = time.time()

    print("\n⏳ Procesando: Ordenando estudiantes con Burbuja Recursivo...")
    ordenados = ordenar_estudiantes_recursivo(estudiantes.copy())

    print("⏳ Procesando: Asignando becas con Recursividad y Backtracking...")
    resultado = asignar_becas_recursivo(ordenados, cupos)

    duracion = time.time() - inicio

    mostrar_resultados(resultado, cupos, len(estudiantes))

    titulo("📈 ANÁLISIS DEL ALGORITMO (RECURSIVIDAD)")
    print(f"\n  • Tiempo de ejecución: {duracion:.6f} segundos")
    print(f"  • Total de llamadas recursivas: {len(estudiantes)} (una por estudiante)")
    print(f"  • Profundidad máxima de recursión: {len(estudiantes)}")
    print(f"  • Complejidad temporal: O(n²) por ordenamiento burbuja recursivo")
    print(f"  • Complejidad espacial: O(n) por pila de recursión")
    print(f"  • Estrategias aplicadas:")
    print(f"    - Recursividad (estrategia principal)")
    print(f"    - Backtracking (reasignación a categorías inferiores)")
    print(f"    - Ordenamiento Burbuja Recursivo (subtema)")


if __name__ == "__main__":
    main()