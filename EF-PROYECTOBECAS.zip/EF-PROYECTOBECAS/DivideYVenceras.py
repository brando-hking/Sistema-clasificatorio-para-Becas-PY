import sys, time
sys.setrecursionlimit(10000)
#Permite que el programa se llame a si mismo hasta 10000 vueltas

NIVEL_STR = {1: "Bajo", 2: "Medio", 3: "Alto"}
UMBRALES = [("excelencia", 18.00, "≥ 18.00"), ("honor", 16.00, "16.00 - 17.99"),
            ("estimulo", 14.00, "14.00 - 15.99")]

#Cremos una clase con el constructor
class Estudiante:
    #Recibe datos(nse,creditos y fecha) y los guarda con el self
    def __init__(self, id, nombre, promedio, nse, creditos, fecha):
        self.id, self.nombre, self.promedio = id, nombre, promedio
        self.nivel_socioeconomico, self.creditos_aprobados, self.fecha_solicitud = nse, creditos, fecha

    #A travez de esto se muestra la informacion limpia(en forma de texto)
    def __repr__(self):
        return f"{self.nombre} (Promedio: {self.promedio}, NSE: {self.nivel_socioeconomico})"


def titulo(texto, ancho=60, c="="):
    print("\n" + c * ancho + f"\n{texto}\n" + c * ancho)


# ========== VALIDACIÓN GENÉRICA ==========
#Validador universal para las entradas por teclado. texto, tipo
# , Condicion(que la regla es que si lambda es true: si no me das una regla 
# cualquier valor de tipo correcto es permitido)
def pedir_valor(mensaje, tipo, condicion=lambda v: True, error="Valor inválido."):
    """Pide un dato por consola validando tipo y una condición extra."""
    while True:
        valor = input(mensaje).strip()
        try:
            valor = tipo(valor)
            if condicion(valor):
                return valor
            print(f"❌ ERROR: {error}")
        except ValueError:
            print(f"❌ ERROR: {error}")

#Se asegura de: X este vacio, solo tenga letras y esapcios,  true si es valido
def validar_nombre(nombre):
    return bool(nombre.strip()) and all(c.isalpha() or c.isspace() for c in nombre)


# ========== ENTRADA DE DATOS ==========
def ingresar_estudiante_manual(id_est, fecha_base):
    titulo(f"INGRESO DE ESTUDIANTE #{id_est}", 50)
    if id_est > 1 and input("\n¿Desea ingresar otro estudiante? (s/n): ").lower().strip() not in ("s", "si"):
        return None

    #Captura y a travez de los validadores, muestra si esta correcto(avanza) o si no muestra error
    while True:
        nombre = input("\nIngrese el nombre completo del estudiante: ").strip()
        if validar_nombre(nombre):
            break
        print("❌ ERROR: El nombre no puede estar vacío y solo debe contener letras y espacios.")
    
    #Captura el promedio a travez de pedir valor
    promedio = pedir_valor("Ingrese el promedio final (0.00 - 20.00): ", float,
                            lambda v: 0 <= v <= 20, "El promedio debe estar entre 0.00 y 20.00")
    
    #Mostramos el menu de opciones, y a travez de las validaciones hacemos que ponga 1,2 o 3. OJO el ns se guarda cm entero    
    print("\nNivel Socioeconómico:\n  1 = Bajo\n  2 = Medio\n  3 = Alto")
    nse = pedir_valor("Seleccione el nivel socioeconómico (1-3): ", int,
                       lambda v: v in (1, 2, 3), "Debe ser 1 (bajo), 2 (medio) o 3 (alto)")
    ##Validacio de creditos, que sea >= 0
    creditos = pedir_valor("Ingrese el número de créditos aprobados: ", int,
                            lambda v: v >= 0, "Debe ser un entero no negativo")

    #Tomamos las variables validas y creamos el objeto. Al final muestra el mensaje de exito y devuelve el objeto listo para guardarlo en lista
    est = Estudiante(id_est, nombre, promedio, nse, creditos, fecha_base + id_est)
    print(f"\n✅ Estudiante '{nombre}' registrado exitosamente.")
    return est

#Define cuantas becas hay disponibles para cada categoria, se lee de forma inversa
#Arranca desde el final el for ...
#Al final crea un diccionario
def ingresar_cupos():
    titulo("CONFIGURACIÓN DE CUPOS POR CATEGORÍA", 50)
    return {
        #Por cada fila que el motor encuentra, frena y hace la pregunta en consola
        cat: pedir_valor(f"\nCupos para Beca {cat.capitalize()} ({rango}): ", int,
                          lambda v: v >= 0, "El número de cupos no puede ser negativo")
        for cat, _, rango in UMBRALES
        #va a la lista de umbrales y lo recorre fila por fila
        #1er dato le da a cat, 2do dato al _ para ignorarlo y el 3ero a rango
    }


# ========== DIVIDE Y VENCERÁS: MERGE SORT ==========
#Compara estudiantes.
def comparar_estudiantes_merge(e1, e2):
    """Criterios: mayor promedio > menor NSE > más créditos > solicitud más antigua."""
    
    #Si tienen notas distintas, gana la nota mas alta
    if e1.promedio != e2.promedio:
        return e1.promedio > e2.promedio

    #En caso sean notas =, gana el de menor nivel socioeconomico
    if e1.nivel_socioeconomico != e2.nivel_socioeconomico:
        return e1.nivel_socioeconomico < e2.nivel_socioeconomico

    #En caso si empatan en nota y dinero, gana el que tenga mas creditos acumulados
    if e1.creditos_aprobados != e2.creditos_aprobados:
        return e1.creditos_aprobados > e2.creditos_aprobados
    return e1.fecha_solicitud < e2.fecha_solicitud
    #En caso todo lo anterior sea igual, el que se digito primero gana.


#Ordena a todos los estudiantes de mayor a menor prioridad
def merge_sort_estudiantes(lista):
    """Divide y Vencerás: O(n log n)."""
    #Si hay un solo estudiante, significa que no se puede dividir mas
    #y lo muestra
    if len(lista) <= 1:
        return lista

    #Halla la posicion central, despues de dividirlo, se llama a si misma
    # hasta que queden la lista suelta    
    medio = len(lista) // 2
    izq = merge_sort_estudiantes(lista[:medio])
    der = merge_sort_estudiantes(lista[medio:])

    resultado, i, j = [], 0, 0

    #Compara al estudiante que esta en la lista izq, con el de la derch.
    #Luego llama a el comparar mergue. Si el de la izq. es mejr, con el true lo mete a el resultado y avanza con el contador izq
    #Si el de la derecha es mejor, se mete a la derecha y su contador avanza
    while i < len(izq) and j < len(der):
        if comparar_estudiantes_merge(izq[i], der[j]):
            resultado.append(izq[i]); i += 1
        else:
            resultado.append(der[j]); j += 1
    
    #En caso ya no haya estudiantes. Esta agarra a los otros estudiantes que hayan sobrado y los pone en la lista resultado
    resultado.extend(izq[i:]); resultado.extend(der[j:])
    return resultado


# ========== BÚSQUEDA BINARIA ITERATIVA ==========

#Corta la lista de estudiantes y busca notasde promedios para agrupoar alumnos
def busqueda_binaria_categoria(estudiantes, umbral):
    """Encuentra el índice donde termina el bloque con promedio >= umbral. O(log n)."""
    #Muestra las parte de la busqueda(al inicio se muestran todas la listas)
    #Empieza en 0 porque asumiendo que no hay ningun estudiante.
    inicio, fin, resultado = 0, len(estudiantes) - 1, 0  # default: nadie cumple el umbral
    
    #El bucle se ejecutara si hay un espacio por revisar
    while inicio <= fin:

        #Por la busq. binaria, el programa apunta directamente al estudiante del centro extacto
        medio = (inicio + fin) // 2

        #Anota cuantos cumplen la regla.
        if estudiantes[medio].promedio >= umbral:
            resultado, inicio = medio + 1, medio + 1
        
        #En caso no la cumplen, elimina la mitad derecha del mapa
        else:
            fin = medio - 1

    #guardando el numero exacto de estudiantes
    return resultado

#Encuentra la info completa de un estudiante, por su nombre
def busqueda_binaria_estudiante(estudiantes, id_buscado):
    #Apunta al 1er alumno y fin al ultimo alumno
    inicio, fin = 0, len(estudiantes) - 1

    #Halla el centro exacto y apunta al estudiante del medio
    while inicio <= fin:
        medio = (inicio + fin) // 2

        #Si el del medio es igual a lo buscado, se detiene y te da el estudiante
        if estudiantes[medio].id == id_buscado:
            return estudiantes[medio]

        #Esta parte elimina la parte izq. en caso que no esta  la info.    
        elif estudiantes[medio].id < id_buscado:
            inicio = medio + 1

        #Borra la parte dercha donde no esta la info
        else:
            fin = medio - 1
    #El bucle se cierra en caso nunca se encontro algo del while
    return None


# ========== FUERZA BRUTA (DESEMPATES) + VORAZ ==========

#Forma un grupo de estudiantes que compiten por la beca y decide quienes se quedan en caso hayan mas postulantes que becas
def asignar_grupo_voraz(grupo, cupo):
    """Si sobran candidatos, fuerza bruta ordena por todos los criterios de desempate."""
    if len(grupo) <= cupo:
        return grupo

    #Si lo anterior no se cumple, se tendra que elegir a los mejores a travez de sortes y la funcion lambda
    # Asi que se ordena de mayor a menor    
    grupo_ordenado = sorted(grupo, key=lambda e: (-e.promedio, e.nivel_socioeconomico,
                                                   -e.creditos_aprobados, e.fecha_solicitud))

    #El : cupo, cuando todo esta ordenado con los mejores, corta desde el 0 a el inidce del grupo
    return grupo_ordenado[:cupo]

#Mueve a los estudiantes que no obtuvieron una beca alta hacia otras con menos peso en caso  tenga lugares
def redistribuir_excedentes_voraz(asignacion, cupos):
    """Voraz: mueve excedentes de una categoría a las inferiores con cupo libre."""
    
    #Extrae los nombres limpios desde umbrales    
    categorias = [c for c, _, _ in UMBRALES]

    #Revisa la categorias una por una de arriba a abajo
    for i, cat in enumerate(categorias):
        excedente = len(asignacion[cat]) - cupos[cat]
        if excedente <= 0:
            continue
        #Agarra los alumnos del final de la lusta, y se gyarda en sobrantes
        sobrantes = asignacion[cat][-excedente:]
        asignacion[cat] = asignacion[cat][:-excedente]

        for cat_inf in categorias[i + 1:]:
            espacio = cupos[cat_inf] - len(asignacion[cat_inf])
            if espacio > 0:
                asignacion[cat_inf].extend(sobrantes[:espacio])
                sobrantes = sobrantes[espacio:]
            if not sobrantes:
                break
        #Si bajo todo y hay alumnos, se crea una lista de sinbeca.
        if sobrantes:
            asignacion.setdefault("sin_beca", []).extend(sobrantes)


# ========== ASIGNACIÓN PRINCIPAL (DIVIDE Y VENCERÁS) ==========
#Clasifica y asigan becas de forma masiva
def asignar_becas_divide_venceras(estudiantes, cupos):
    """
    1. DIVIDIR: separar por categoría (búsqueda binaria)
    2. VENCER: asignar vorazmente + fuerza bruta en cada grupo
    3. COMBINAR: redistribuir excedentes
    """

    #Separa inmediatamente a los alumnos desaprobados y enviarlos a la lista de sin_beca
    asignacion = {"excelencia": [], "honor": [], "estimulo": [], "sin_beca": []}

    validos = [e for e in estudiantes if e.promedio >= 14.00]
    asignacion["sin_beca"] = [e for e in estudiantes if e.promedio < 14.00]
    if not validos:
        return asignacion

    #Ordena de ma yor a menor prioridad por el merge sort. 
    validos = merge_sort_estudiantes(validos)

    #Halla los indices extactos de corte. dividiendolo en subgrupos independientes
    #Y al final muestra un resumen estadistico
    idx_exc = busqueda_binaria_categoria(validos, 18.00)
    idx_hon = busqueda_binaria_categoria(validos, 16.00)
    grupos = {
        "excelencia": validos[:idx_exc],
        "honor": validos[idx_exc:idx_hon],
        "estimulo": validos[idx_hon:],
    }

    print("\n📊 ANÁLISIS DE DIVISIÓN:")
    for cat, _, rango in UMBRALES:
        print(f"  Grupo {cat.capitalize()} ({rango}): {len(grupos[cat])} estudiantes")

    #Ejecuta el programa por separado, llama a asignar_alg_voraz, poniendo a solo los mejores de esta asingacion
    for cat in grupos:
        asignacion[cat] = asignar_grupo_voraz(grupos[cat], cupos[cat])

    #Reubica a los alumnos que se quedan fuera de su grupo de becas ideal.
    redistribuir_excedentes_voraz(asignacion, cupos)

    asignados = [e for cat in ("excelencia", "honor", "estimulo") for e in asignacion[cat]]
    for e in validos:
        if e not in asignados and e not in asignacion["sin_beca"]:
            asignacion["sin_beca"].append(e)
    #Al final retorna el diccionario completo
    return asignacion


# ========== RESULTADOS ==========
def mostrar_resultados(asignacion, cupos, total):
    titulo("📊 RESULTADOS DE ASIGNACIÓN DE BECAS\n   Estrategia: Divide y Vencerás")
    con_beca = sum(len(asignacion[c]) for c in ("excelencia", "honor", "estimulo"))
    print(f"\n📋 Total de estudiantes procesados: {total}")
    print(f"✅ Estudiantes con beca asignada: {con_beca}")
    print(f"❌ Estudiantes sin beca: {len(asignacion['sin_beca'])}")

    emojis = {"excelencia": "🌟 BECA EXCELENCIA", "honor": "🎓 BECA HONOR", "estimulo": "📚 BECA ESTÍMULO"}
    for cat, _, rango in UMBRALES:
        print(f"\n{emojis[cat]} ({rango})")
        print(f"Cupos disponibles: {cupos[cat]} | Asignados: {len(asignacion[cat])}")
        print("-" * 50)
        if not asignacion[cat]:
            print("  Sin asignaciones en esta categoría")
        for i, e in enumerate(asignacion[cat], 1):
            print(f"  {i}. {e.nombre}\n     Promedio: {e.promedio:.2f} | "
                  f"NSE: {NIVEL_STR[e.nivel_socioeconomico]} | Créditos: {e.creditos_aprobados}")

    if asignacion["sin_beca"]:
        print(f"\n❌ ESTUDIANTES SIN BECA ({len(asignacion['sin_beca'])}):\n" + "-" * 50)
        no_alcanzan = [e for e in asignacion["sin_beca"] if e.promedio < 14.00]
        sin_cupo = [e for e in asignacion["sin_beca"] if e.promedio >= 14.00]

        if no_alcanzan:
            print(f"\n  No alcanzan nota mínima (< 14.00): {len(no_alcanzan)}")
            for e in no_alcanzan[:5]:
                print(f"    - {e.nombre} (Promedio: {e.promedio:.2f})")
            if len(no_alcanzan) > 5:
                print(f"    ... y {len(no_alcanzan) - 5} más")

        if sin_cupo:
            print(f"\n  Sin cupo disponible en su categoría: {len(sin_cupo)}")
            for e in sin_cupo[:5]:
                print(f"    - {e.nombre} (Promedio: {e.promedio:.2f})")
            if len(sin_cupo) > 5:
                print(f"    ... y {len(sin_cupo) - 5} más")


def mostrar_resumen_estudiantes(estudiantes):
    titulo("📋 LISTA DE ESTUDIANTES INGRESADOS")
    print(f"\nTotal de estudiantes: {len(estudiantes)}\n")
    print(f"{'ID':<5} {'Nombre':<25} {'Promedio':<10} {'NSE':<8} {'Créditos':<10}")
    print("-" * 58)
    for e in estudiantes:
        print(f"{e.id:<5} {e.nombre:<25} {e.promedio:<10.2f} {NIVEL_STR[e.nivel_socioeconomico]:<8} {e.creditos_aprobados:<10}")


# ========== PROGRAMA PRINCIPAL ==========
def main():
    titulo("🎓 SISTEMA DE ASIGNACIÓN DE BECAS UNIVERSITARIAS\n   Estrategia: Divide y Vencerás")
    print("\n📌 ESTRATEGIAS APLICADAS:")
    print("   1. Merge Sort (Divide y Vencerás) - Ordenamiento")
    print("   2. Búsqueda Binaria Iterativa - División por categorías")
    print("   3. Algoritmo Voraz - Asignación por grupo")
    print("   4. Fuerza Bruta - Desempates en subgrupos")

    cupos = ingresar_cupos()

    titulo("INGRESO DE ESTUDIANTES POSTULANTES")
    estudiantes, id_est, fecha_base = [], 1, 1000
    while True:
        est = ingresar_estudiante_manual(id_est, fecha_base)
        if est is None:
            if id_est == 1:
                print("\n❌ Debe ingresar al menos un estudiante.")
                continue
            break
        estudiantes.append(est)
        id_est += 1

    mostrar_resumen_estudiantes(estudiantes)

    inicio = time.time()
    resultado = asignar_becas_divide_venceras(estudiantes, cupos)
    duracion = time.time() - inicio

    mostrar_resultados(resultado, cupos, len(estudiantes))

    titulo("📈 ANÁLISIS DEL ALGORITMO (DIVIDE Y VENCERÁS)")
    print(f"\n  • Tiempo de ejecución: {duracion:.6f} segundos")
    print(f"  • Total de estudiantes procesados: {len(estudiantes)}")
    print(f"  • Complejidad temporal: O(n log n) por Merge Sort")
    print(f"  • Complejidad espacial: O(n) por arrays temporales")
    print(f"  • Profundidad máxima de recursión: ~{len(estudiantes).bit_length()} (log₂ n)")


if __name__ == "__main__":
    main()